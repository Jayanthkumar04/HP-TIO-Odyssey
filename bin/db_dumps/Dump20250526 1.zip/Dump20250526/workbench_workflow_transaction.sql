-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: workbench
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `workflow_transaction`
--

DROP TABLE IF EXISTS `workflow_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_transaction` (
  `running_instance_id` char(36) NOT NULL,
  `workflow_id` int NOT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `workflow_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`running_instance_id`),
  KEY `workflow_id` (`workflow_id`),
  CONSTRAINT `workflow_transaction_ibfk_1` FOREIGN KEY (`workflow_id`) REFERENCES `workflow_master` (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_transaction`
--

LOCK TABLES `workflow_transaction` WRITE;
/*!40000 ALTER TABLE `workflow_transaction` DISABLE KEYS */;
INSERT INTO `workflow_transaction` VALUES ('1c6277f5-e1af-49bd-a4e0-4b33d690aacc',1,'2025-05-26T12:01:10.679276700',NULL,'RUNNING'),('203ff788-09ee-4ba4-97ca-4d3a14ba785b',1,'2025-05-22 15:10:04',NULL,'RUNNING'),('547915bf-7ceb-4820-b877-c175fed0253b',1,'2025-05-24T22:06:33.299928100',NULL,'RUNNING'),('98c033af-9184-48dd-a9f4-6af5d59325c4',1,'2025-05-25T10:01:58.653315700',NULL,'RUNNING'),('9db51cac-7a84-4eb5-a929-b53eac1961bc',1,'2025-05-24T19:17:40.833924',NULL,'RUNNING'),('ddb3c09a-a5d9-4432-ae24-bd36cb0c3d8f',1,'2025-05-22 15:23:08',NULL,'RUNNING'),('e06d3fc6-fcd5-40b4-bea3-b603742e40a3',1,'2025-05-22 15:23:22',NULL,'RUNNING'),('edafa4c0-a8b9-4a9b-834f-9dcfa12d7389',1,'2025-05-25T09:58:11.941510',NULL,'RUNNING');
/*!40000 ALTER TABLE `workflow_transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-26 18:59:16
