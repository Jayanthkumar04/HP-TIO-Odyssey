-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: workbench
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `workflow_transaction`
--

DROP TABLE IF EXISTS `workflow_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_transaction` (
  `running_instance_id` char(36) NOT NULL,
  `workflow_id` int NOT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `workflow_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`running_instance_id`),
  KEY `workflow_id` (`workflow_id`),
  CONSTRAINT `workflow_transaction_ibfk_1` FOREIGN KEY (`workflow_id`) REFERENCES `workflow_master` (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_transaction`
--

LOCK TABLES `workflow_transaction` WRITE;
/*!40000 ALTER TABLE `workflow_transaction` DISABLE KEYS */;
INSERT INTO `workflow_transaction` VALUES ('27a15b59-99cf-4178-acab-c9af6e36ccf7',1,'2025-05-27T10:12:47.501224',NULL,'RUNNING'),('3a28e398-a56b-4b55-a09f-2251ee7a9d75',1,'2025-05-27T10:16:28.540184400',NULL,'RUNNING'),('6faff16c-3d66-41a2-85f1-c65189af5162',1,'2025-05-28T05:31:18.852259700',NULL,'RUNNING'),('727e6169-0913-4250-a39f-f3c1b4c0194c',1,'2025-05-27T09:55:06.561885300',NULL,'RUNNING'),('9febad58-28f4-4aee-9633-36d5f40b1a28',1,'2025-05-27T12:08:27.708040600',NULL,'RUNNING'),('b88a4f50-2a90-4248-b09c-f5ba8eed7789',1,'2025-05-28T05:44:28.892723900',NULL,'RUNNING'),('e25b40ac-f49d-453e-9a35-688e916fc46b',1,'2025-05-27T08:49:27.354613700',NULL,'RUNNING'),('eb550f5d-5167-4d84-9838-f197edf6c2a6',1,'2025-05-27T09:43:25.342842',NULL,'RUNNING'),('f699ada2-f1a2-452f-bead-c43cd1a6f523',1,'2025-05-28T04:47:28.475832900','2025-05-28T05:00:59.689020200','COMPLETED');
/*!40000 ALTER TABLE `workflow_transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-28  6:52:11
