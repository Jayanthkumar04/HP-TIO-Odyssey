-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: workbench
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_transaction`
--

DROP TABLE IF EXISTS `activity_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_transaction` (
  `transaction_id` bigint NOT NULL AUTO_INCREMENT,
  `workflow_id` int NOT NULL,
  `running_instance_id` char(36) DEFAULT NULL,
  `step_no` int NOT NULL,
  `assigned_to` varchar(255) DEFAULT NULL,
  `activity_type` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `activity_status` varchar(255) DEFAULT NULL,
  `activity_input` varchar(255) DEFAULT NULL,
  `activity_output` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `workflow_id` (`workflow_id`),
  KEY `running_instance_id` (`running_instance_id`),
  CONSTRAINT `activity_transaction_ibfk_1` FOREIGN KEY (`workflow_id`) REFERENCES `workflow_master` (`workflow_id`),
  CONSTRAINT `activity_transaction_ibfk_2` FOREIGN KEY (`running_instance_id`) REFERENCES `workflow_transaction` (`running_instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_transaction`
--

LOCK TABLES `activity_transaction` WRITE;
/*!40000 ALTER TABLE `activity_transaction` DISABLE KEYS */;
INSERT INTO `activity_transaction` VALUES (1,1,'e25b40ac-f49d-453e-9a35-688e916fc46b',1,'Generate Test Scenarios','Automated','2025-05-27T08:49:27.377432300',NULL,'STARTED',NULL,NULL,NULL),(2,1,'eb550f5d-5167-4d84-9838-f197edf6c2a6',1,'Generate Test Scenarios','Automated','2025-05-27T09:43:25.366107100',NULL,'STARTED',NULL,NULL,NULL),(3,1,'727e6169-0913-4250-a39f-f3c1b4c0194c',1,'Generate Test Scenarios','Automated','2025-05-27T09:55:06.584415100','2025-05-27T09:56:37.696375','COMPLETED',NULL,'{\"outputUrl\": \"https://ascendionavaplus.atlassian.net/browse/HAP-19\"}','https://ascendionavaplus.atlassian.net/browse/HAP-19'),(4,1,'727e6169-0913-4250-a39f-f3c1b4c0194c',2,'Verify Test Scenarios','MANUAL','2025-05-27T09:56:37.718483800','2025-05-27T10:08:08.549726800','COMPLETED',NULL,NULL,'https://ascendionavaplus.atlassian.net/browse/HAP-19'),(5,1,'727e6169-0913-4250-a39f-f3c1b4c0194c',3,'Generate Test Cases','Automated','2025-05-27T10:08:08.569082500',NULL,'STARTED',NULL,NULL,NULL),(6,1,'27a15b59-99cf-4178-acab-c9af6e36ccf7',1,'Generate Test Scenarios','Automated','2025-05-27T10:12:47.517238600','2025-05-27T10:15:17.312606800','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://jira.example.com/browse/HAP-12345\"\n}','https://jira.example.com/browse/HAP-12345'),(7,1,'27a15b59-99cf-4178-acab-c9af6e36ccf7',2,'Verify Test Scenarios','MANUAL','2025-05-27T10:15:17.325613600',NULL,'ASSIGNED',NULL,NULL,'https://jira.example.com/browse/HAP-12345'),(8,1,'3a28e398-a56b-4b55-a09f-2251ee7a9d75',1,'Generate Test Scenarios','Automated','2025-05-27T10:16:28.559867700','2025-05-27T10:18:14.182677900','COMPLETED',NULL,'{\"outputUrl\": \"https://ascendionavaplus.atlassian.net/browse/HAP-21\"}','https://ascendionavaplus.atlassian.net/browse/HAP-21'),(9,1,'3a28e398-a56b-4b55-a09f-2251ee7a9d75',2,'Verify Test Scenarios','MANUAL','2025-05-27T10:18:14.208325800','2025-05-27T10:19:01.759300500','COMPLETED',NULL,NULL,'https://ascendionavaplus.atlassian.net/browse/HAP-21'),(10,1,'3a28e398-a56b-4b55-a09f-2251ee7a9d75',3,'Generate Test Cases','Automated','2025-05-27T10:19:01.773879',NULL,'STARTED',NULL,NULL,NULL),(11,1,'9febad58-28f4-4aee-9633-36d5f40b1a28',1,'Generate Test Scenarios','Automated','2025-05-27T12:08:27.804081800','2025-05-27T12:12:19.772334300','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://ascendionavaplus.atlassian.net/browse/HAP-26\"\n}','https://ascendionavaplus.atlassian.net/browse/HAP-26'),(12,1,'9febad58-28f4-4aee-9633-36d5f40b1a28',2,'Verify Test Scenarios','MANUAL','2025-05-27T12:12:19.792644900','2025-05-27T12:14:24.555439900','COMPLETED',NULL,NULL,'https://ascendionavaplus.atlassian.net/browse/HAP-26'),(13,1,'9febad58-28f4-4aee-9633-36d5f40b1a28',3,'Generate Test Cases','Automated','2025-05-27T12:14:24.582749200','2025-05-27T12:16:34.108340600','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0\"\n}','https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(14,1,'9febad58-28f4-4aee-9633-36d5f40b1a28',4,'Verify Test Cases','MANUAL','2025-05-27T12:16:34.113880400','2025-05-27T12:17:06.057986300','COMPLETED',NULL,NULL,'https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(15,1,'9febad58-28f4-4aee-9633-36d5f40b1a28',5,'Automation Script Generator','Automated','2025-05-27T12:17:06.078065200',NULL,'STARTED',NULL,NULL,NULL),(16,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',1,'Generate Test Scenarios','Automated','2025-05-28T04:47:28.580948700','2025-05-28T04:48:50.044522400','COMPLETED',NULL,'```json\n{\n  \"outputUrl\": \"https://ascendionavaplus.atlassian.net/browse/HAP-38\"\n}\n```','https://ascendionavaplus.atlassian.net/browse/HAP-38'),(17,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',2,'Verify Test Scenarios','MANUAL','2025-05-28T04:48:50.068416600','2025-05-28T04:50:19.773428','COMPLETED',NULL,NULL,'https://ascendionavaplus.atlassian.net/browse/HAP-38'),(18,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',3,'Generate Test Cases','Automated','2025-05-28T04:50:19.790509500','2025-05-28T04:51:36.590414400','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0\"\n}','https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(19,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',4,'Verify Test Cases','MANUAL','2025-05-28T04:51:36.615674500','2025-05-28T04:53:35.306259600','COMPLETED',NULL,NULL,'https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(20,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',5,'Automation Script Generator','Automated','2025-05-28T04:53:35.329481300','2025-05-28T04:57:13.216693900','COMPLETED',NULL,'{\n \"outputUrl\" : \"https://github.com/AnushreeMSAscendion/ascendion/tree/main/build\"\n}','https://github.com/AnushreeMSAscendion/ascendion/tree/main/build'),(21,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',6,'Verify Test Scripts','MANUAL','2025-05-28T04:57:13.229693900','2025-05-28T04:58:19.348204300','COMPLETED',NULL,NULL,'https://github.com/AnushreeMSAscendion/ascendion/tree/main/build'),(22,1,'f699ada2-f1a2-452f-bead-c43cd1a6f523',7,'Execute Test Scripts','Automated','2025-05-28T04:58:19.364548600','2025-05-28T05:00:59.658384700','COMPLETED',NULL,'{\n  \"statusCode\": 200,\n  \"message\": \"Success\",\n  \"data\": \"Batch file executed successfully.\"\n}',NULL),(23,1,'6faff16c-3d66-41a2-85f1-c65189af5162',1,'Generate Test Scenarios','Automated','2025-05-28T05:31:18.934920500','2025-05-28T05:33:40.565557','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://jira.example.com/browse/HAP-123\"\n}','https://jira.example.com/browse/HAP-123'),(24,1,'6faff16c-3d66-41a2-85f1-c65189af5162',2,'Verify Test Scenarios','MANUAL','2025-05-28T05:33:40.585301400',NULL,'ASSIGNED',NULL,NULL,'https://jira.example.com/browse/HAP-123'),(25,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',1,'Generate Test Scenarios','Automated','2025-05-28T05:44:28.937022800','2025-05-28T05:45:20.374331100','COMPLETED',NULL,'{\"outputUrl\": \"https://ascendionavaplus.atlassian.net/browse/HAP-40\"}','https://ascendionavaplus.atlassian.net/browse/HAP-40'),(26,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',2,'Verify Test Scenarios','MANUAL','2025-05-28T05:45:20.781757800','2025-05-28T05:51:05.896842500','COMPLETED',NULL,NULL,'https://ascendionavaplus.atlassian.net/browse/HAP-40'),(27,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',3,'Generate Test Cases','Automated','2025-05-28T05:51:05.920256700','2025-05-28T05:52:23.806074900','COMPLETED',NULL,'{\n  \"outputUrl\": \"https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0\"\n}','https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(28,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',4,'Verify Test Cases','MANUAL','2025-05-28T05:52:23.819097400','2025-05-28T05:53:48.901301400','COMPLETED',NULL,NULL,'https://avaplusqe.testrail.io/index.php?/suites/view/2&group_by=cases:section_id&group_order=asc&display_deleted_cases=0'),(29,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',5,'Automation Script Generator','Automated','2025-05-28T05:53:48.914116400','2025-05-28T05:55:54.809007600','COMPLETED',NULL,'{\n \"outputUrl\" : \"https://github.com/AnushreeMSAscendion/ascendion/tree/main/build\"\n}','https://github.com/AnushreeMSAscendion/ascendion/tree/main/build'),(30,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',6,'Verify Test Scripts','MANUAL','2025-05-28T05:55:54.822733900','2025-05-28T05:56:31.832434500','COMPLETED',NULL,NULL,'https://github.com/AnushreeMSAscendion/ascendion/tree/main/build'),(31,1,'b88a4f50-2a90-4248-b09c-f5ba8eed7789',7,'Execute Test Scripts','Automated','2025-05-28T05:56:31.847020',NULL,'STARTED',NULL,NULL,NULL);
/*!40000 ALTER TABLE `activity_transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-28  6:52:12
